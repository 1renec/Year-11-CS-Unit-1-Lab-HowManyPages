import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter your age:");
        int myAge;
        myAge = scan.nextInt();
        int page = 100-myAge;
        System.out.println(myAge + " years old should read at least " + page + " pages before giving up on a book. " );
    }

}